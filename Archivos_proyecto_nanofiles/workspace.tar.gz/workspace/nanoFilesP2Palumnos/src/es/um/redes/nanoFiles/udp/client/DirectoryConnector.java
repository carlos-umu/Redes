package es.um.redes.nanoFiles.udp.client;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import es.um.redes.nanoFiles.application.NanoFiles;
import es.um.redes.nanoFiles.udp.message.DirMessage;
import es.um.redes.nanoFiles.udp.message.DirMessageOps;
import es.um.redes.nanoFiles.util.FileInfo;

public class DirectoryConnector {

	private static final int DIRECTORY_PORT = 6868;
	private static final int TIMEOUT = 50000;

	private static final int MAX_NUMBER_OF_ATTEMPTS = 5;

	private DatagramSocket socket;

	private InetSocketAddress directoryAddress;

	private String directoryHostname;

	public DirectoryConnector(String hostname) throws IOException {
		// Guardamos el string con el nombre/IP del host
		directoryHostname = hostname;
		InetAddress serverIp = InetAddress.getByName(hostname);
		directoryAddress = new InetSocketAddress(serverIp, DIRECTORY_PORT);
		this.socket = new DatagramSocket();

	}

	/**
	 * Método para enviar y recibir datagramas al/del directorio
	 * 
	 * @param requestData los datos a enviar al directorio (mensaje de solicitud)
	 * @return los datos recibidos del directorio (mensaje de respuesta)
	 * @throws IOException
	 *
	 */
	private byte[] sendAndReceiveDatagrams(byte[] requestData) {
		byte responseData[] = new byte[DirMessage.PACKET_MAX_SIZE];
		byte response[] = null;
		if (directoryAddress == null) {
			System.err.println("DirectoryConnector.sendAndReceiveDatagrams: UDP server destination address is null!");
			System.err.println("DirectoryConnector.sendAndReceiveDatagrams: make sure constructor initializes field \"directoryAddress\"");
			System.exit(-1);
		}
		if (socket == null) {
			System.err.println("DirectoryConnector.sendAndReceiveDatagrams: UDP socket is null!");
			System.err.println("DirectoryConnector.sendAndReceiveDatagrams: make sure constructor initializes field \"socket\"");
			System.exit(-1);
		}

		DatagramPacket packetToServer = new DatagramPacket(requestData, requestData.length, directoryAddress);
		DatagramPacket packetFromServer = new DatagramPacket(responseData, responseData.length);

		int intentos = 0;
		boolean bandera = false;
		while (!bandera && intentos < MAX_NUMBER_OF_ATTEMPTS) {
			try {
				socket.send(packetToServer);
				this.socket.setSoTimeout(TIMEOUT);
				socket.receive(packetFromServer);
				bandera = true;
			} catch (SocketTimeoutException e) {
				intentos++;
				System.err.println("Error:SocketTimeException:DirectoryConnector.");
			} catch (IOException e) {
				System.err.println("Error:IOException:DirectoryConnector.");
			}
		}
		if (!bandera) {
			System.err.println("Mas de 5 intentos.");
			System.exit(1);

		}

		int longitud = packetFromServer.getLength();
		// La respuesta va a contener unicamente los datos recibidos
		response = new byte[longitud]; 

		for (int i = 0; i < longitud; i++) {
			response[i] = responseData[i];
		}

		return response;
	}

	/**
	 * Método para probar la comunicación con el directorio mediante el envío y
	 * recepción de mensajes sin formatear ("en crudo")
	 * 
	 * @return verdadero si se ha enviado un datagrama y recibido una respuesta
	 * 
	 */
	public boolean testSendAndReceive() {
		String palabra = "ping";
		byte[] mensaje = palabra.getBytes();
		byte[] respuesta;
		boolean success = false;
		respuesta = sendAndReceiveDatagrams(mensaje);
		String palabraRecibida = new String(respuesta);
		if (palabraRecibida.startsWith("pingok"))
			success = true;
		return success;
	}

	public String getDirectoryHostname() {
		return directoryHostname;
	}

	/**
	 * Método para "hacer ping" al directorio, comprobar que está operativo y que
	 * usa un protocolo compatible. Este método no usa mensajes bien formados.
	 * 
	 * @return Verdadero si
	 */
	public boolean pingDirectoryRaw() {
		boolean success = false;
		String palabra = "ping&" + NanoFiles.PROTOCOL_ID;
		byte[] mensaje = palabra.getBytes();
		byte[] respuesta;
		respuesta = sendAndReceiveDatagrams(mensaje);
		String palabraRecibida = new String(respuesta);
		if (palabraRecibida.startsWith("welcome")) {
			System.out.println("Palabra recibida: welcome -> success.");
			success = true;
		} else {
			System.err.println("Palabra recibida: denied -> fail.");
		}
		return success;
	}

	/**
	 * Método para "hacer ping" al directorio, comprobar que está operativo y que es
	 * compatible.
	 * 
	 * @return Verdadero si el directorio está operativo y es compatible
	 */
	public boolean pingDirectory() { //[testmode]=false
		boolean success = false;
		
		DirMessage operation = new DirMessage(DirMessageOps.OPERATION_PING);
		operation.setProtocolID(NanoFiles.PROTOCOL_ID);
		String operationString = operation.toString();
		byte[] mensajeBytes = operationString.getBytes();
		byte[] respuestaBytes = sendAndReceiveDatagrams(mensajeBytes);
		
		if (respuestaBytes == null) {
			System.err.println("No hay respuesta del directorio");
			return false;
		}

		String recibidoString = new String(respuestaBytes);
		DirMessage recibido = DirMessage.fromString(recibidoString);
		//Si mensaje recibido es welcome  success=true
		if (recibido.getOperation().equals(DirMessageOps.OPERATION_WELCOME)) { 
			success = true;
		}
		return success;
	}

	/**
	 * Método para dar de alta como servidor de ficheros en el puerto indicado y
	 * publicar los ficheros que este peer servidor está sirviendo.
	 * 
	 * @param serverPort El puerto TCP en el que este peer sirve ficheros a otros
	 * @param files      La lista de ficheros que este peer está sirviendo.
	 * @return Verdadero si el directorio tiene registrado a este peer como servidor
	 *         y acepta la lista de ficheros, falso en caso contrario.
	 */
	public boolean registerFileServer(int serverPort, FileInfo[] files) {
		boolean success = false;

		// ENVIAMOS AL DIRECTORIO UNA SOLICITUD
		DirMessage operation = new DirMessage(DirMessageOps.OPERATION_SERVE); 
		operation.setServers(new InetSocketAddress(serverPort));
		operation.setFiles(files);
		String operationString = operation.toString();
		byte[] mensajeBytes = operationString.getBytes();
		byte[] respuestaBytes = sendAndReceiveDatagrams(mensajeBytes);
		if (respuestaBytes == null) {
			System.err.println("No hay respuesta del directorio");
			return false;
		}

		// RECIbIMOS LA RESPUESTA Y LA PROCESAMOS
		String recibidoString = new String(respuestaBytes);
		DirMessage recibido = DirMessage.fromString(recibidoString);
		if (recibido.getOperation().equals(DirMessageOps.OPERATION_SEND_SERVE)) {
			success = true;
		}
		return success;
	}

	/**
	 * Método para obtener la lista de ficheros que los peers servidores han
	 * publicado al directorio. Para cada fichero se debe obtener un objeto FileInfo
	 * con nombre, tamaño y hash. Opcionalmente, puede incluirse para cada fichero,
	 * su lista de peers servidores que lo están compartiendo.
	 * 
	 * @return Los ficheros publicados al directorio, o null si el directorio no
	 *         pudo satisfacer nuestra solicitud
	 * 
	 */

	public FileInfo[] getFileList() {
		FileInfo[] filelist = new FileInfo[0];
		DirMessage operation = new DirMessage(DirMessageOps.OPERATION_FILELIST);
		String operationString = operation.toString();
		byte[] mensajeBytes = operationString.getBytes();
		byte[] respuestaBytes = sendAndReceiveDatagrams(mensajeBytes);
		String recibidoString = new String(respuestaBytes);
		DirMessage recibido = DirMessage.fromString(recibidoString);
		if (recibido.getOperation().equals(DirMessageOps.OPERATION_SEND_FILELIST)) {
			List<FileInfo> files = recibido.getFiles();
			filelist = files.toArray(filelist);	
		}
		return filelist;
	}

	/**
	 * Método para obtener la lista de servidores que tienen un fichero cuyo nombre
	 * contenga la subcadena dada.
	 * 
	 * @filenameSubstring Subcadena del nombre del fichero a buscar
	 * 
	 * @return La lista de direcciones de los servidores que han publicado al
	 *         directorio el fichero indicado. Si no hay ningún servidor, devuelve
	 *         una lista vacía.
	 */
	public InetSocketAddress[] getServersSharingThisFile(String filenameSubstring) {
		InetSocketAddress[] serversList = new InetSocketAddress[0];

		FileInfo fichero = new FileInfo();
		fichero.fileName = filenameSubstring;

		DirMessage download = new DirMessage(DirMessageOps.OPERATION_DOWNLOAD);
		download.setFiles(fichero);
		byte[] mensajeBytes = download.toString().getBytes();
		byte[] respuestaBytes = sendAndReceiveDatagrams(mensajeBytes);

		if (respuestaBytes == null) {
			System.err.println("No hay respuesta del directorio");
			return serversList;
		}

		String recibidoString = new String(respuestaBytes);
		DirMessage recibido = DirMessage.fromString(recibidoString);
		serversList = recibido.getIp().toArray(new InetSocketAddress[0]);
		return serversList;
	}

	/**
	 * Método para darse de baja como servidor de ficheros.
	 * 
	 * @return Verdadero si el directorio tiene registrado a este peer como servidor
	 *         y ha dado de baja sus ficheros.
	 */
	public boolean unregisterFileServer() {
		boolean success = false;
		return success;
	}

}
