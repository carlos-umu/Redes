package es.um.redes.nanoFiles.udp.server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import es.um.redes.nanoFiles.application.NanoFiles;
import es.um.redes.nanoFiles.udp.message.DirMessage;
import es.um.redes.nanoFiles.udp.message.DirMessageOps;
import es.um.redes.nanoFiles.util.FileInfo;

public class NFDirectoryServer {
	/**
	 * Número de puerto UDP en el que escucha el directorio
	 */
	public static final int DIRECTORY_PORT = 6868;

	/**
	 * Socket de comunicación UDP con el cliente UDP (DirectoryConnector)
	 */
	private DatagramSocket socket = null;
	


	//servidor guarda el fichero tal quien lo tiene
	private static Map<FileInfo,List<InetSocketAddress>> Maparchivos =new HashMap<>(); //para cada archivo tiene todas las direccion 
	
	public static Map<FileInfo,List<InetSocketAddress>> getMaparchivos(){
    	return Collections.unmodifiableMap(Maparchivos);
    }
	
	
	/**
	 * Probabilidad de descartar un mensaje recibido en el directorio (para simular
	 * enlace no confiable y testear el código de retransmisión)
	 */
	private double messageDiscardProbability;

	private DatagramPacket datagramReceivedFromClient;

	public NFDirectoryServer(double corruptionProbability) throws SocketException {
		/*
		 * Guardar la probabilidad de pérdida de datagramas (simular enlace no
		 * confiable)
		 */
		messageDiscardProbability = corruptionProbability;
		
		socket = new DatagramSocket(DIRECTORY_PORT);
		


		
		if (NanoFiles.testModeUDP) {
			if (socket == null) {
				System.err.println("[testMode] NFDirectoryServer: code not yet fully functional.\n"
						+ "Check that all TODOs in its constructor and 'run' methods have been correctly addressed!");
				System.exit(-1);
			}
		}
		
	}

	public DatagramPacket receiveDatagram() {
		DatagramPacket datagramReceivedFromClient = null;
		boolean datagramReceived = false;
		while (!datagramReceived) {	
			byte[] recepBuf = new byte[DirMessage.PACKET_MAX_SIZE]; 		//buffer
			datagramReceivedFromClient = new DatagramPacket(recepBuf, recepBuf.length);
			try {
				socket.receive(datagramReceivedFromClient);
				datagramReceived =true;
			}catch(SocketTimeoutException e) {
			System.out.println("socketimeout");

			}catch(IOException e) {
				System.out.println("ioexception");
			}
			



			if (datagramReceivedFromClient == null) {
				System.err.println("[testMode] NFDirectoryServer.receiveDatagram: code not yet fully functional.\n"
						+ "Check that all TODOs have been correctly addressed!");
				System.exit(-1);
			} else {
				// Vemos si el mensaje debe ser ignorado (simulación de un canal no confiable)
				double rand = Math.random();
				if (rand < messageDiscardProbability) {
					System.err.println(
							"Directory ignored datagram from " + datagramReceivedFromClient.getSocketAddress());
				} else {
					datagramReceived = true;
					System.out
							.println("Directory received datagram from " + datagramReceivedFromClient.getSocketAddress()
									+ " of size " + datagramReceivedFromClient.getLength() + " bytes.");
				}
			}

		}

		return datagramReceivedFromClient;
	}

	public void runTest() throws IOException {

		System.out.println("[testMode] Directory starting...");

		System.out.println("[testMode] Attempting to receive 'ping' message...");
		DatagramPacket rcvDatagram = receiveDatagram();
		sendResponseTestMode(rcvDatagram);

		System.out.println("[testMode] Attempting to receive 'ping&PROTOCOL_ID' message...");
		rcvDatagram = receiveDatagram();
		sendResponseTestMode(rcvDatagram);
	}

	private void sendResponseTestMode(DatagramPacket pkt) throws IOException {
		String messageToClient = new String(pkt.getData(), 0, pkt.getLength());
		System.out.println("Data received: " + messageToClient);		String message = new String();
		if(messageToClient.startsWith("ping&")) {
			String id= messageToClient.substring(5); 			//coge de a partir del &		//de que la cadena recibida no sea exactamente "ping", comprobar si comienza
			if(id.equals(NanoFiles.PROTOCOL_ID)) {				//por "ping&" (es del tipo "ping&PROTOCOL_ID", donde PROTOCOL_ID será el identificador del protocolo diseñado por el grupo de prácticas (ver
				 message ="welcome"; 							//NanoFiles.PROTOCOL_ID). Se debe extraer el "protocol_id" de la cadena recibida y comprobar que su valor coincide con el de NanoFiles.PROTOCOL_ID,
			}else{												//en cuyo caso se responderá con "welcome" (en otro caso, "denied").
			 	message ="denied"; 
			}
			
		}else if(messageToClient.startsWith("ping")) {			//TODO: (Boletín Estructura-NanoFiles) Ampliar el código para que, en el caso
			
			message ="pingok";
		}else {
			 message ="invalid";
		}
		
		//MANDAR LA RESPUESTA
		byte[] dataToClient = message.getBytes();
		InetSocketAddress clientAddr = (InetSocketAddress) pkt.getSocketAddress();
		DatagramPacket pktToClient = new DatagramPacket(dataToClient, dataToClient.length, clientAddr);
		socket.send(pktToClient);
	}

	public void run() throws IOException {

		System.out.println("Directory starting...");

		while (true) { // Bucle principal del servidor de directorio
			DatagramPacket rcvDatagram = receiveDatagram();

			sendResponse(rcvDatagram);

		}
	}

	private void sendResponse(DatagramPacket pkt) throws IOException {
		
		String operation = DirMessageOps.OPERATION_INVALID; 
		String messageToClient = new String(pkt.getData(), 0, pkt.getLength());
		System.out.println("Data received: " + messageToClient);		
		DirMessage receivedmessage = DirMessage.fromString(messageToClient);
		
		DirMessage msgToSend =null;
		operation = receivedmessage.getOperation();
		
		switch (operation) {
			case DirMessageOps.OPERATION_PING: {

				if (NanoFiles.PROTOCOL_ID.equals(receivedmessage.getProtocolId())) {
		        	msgToSend = new DirMessage(DirMessageOps.OPERATION_WELCOME);
		        } else {
		        	msgToSend = new DirMessage(DirMessageOps.OPERATION_DENIED);
		        }
			break;
			}
			case DirMessageOps.OPERATION_FILELIST: {
					FileInfo[] listaficheros= {};
					if(!Maparchivos.isEmpty()) {
						listaficheros= Maparchivos.keySet().toArray(new FileInfo[0]); //es necesario el casting porque devuevle array de object
						
					}
					msgToSend = new DirMessage(DirMessageOps.OPERATION_SEND_FILELIST);
					msgToSend.setFiles(listaficheros);
			break;
			}
			case DirMessageOps.OPERATION_SERVE: {
				List<InetSocketAddress> direccionesDeficheros;
				InetSocketAddress direccion= new InetSocketAddress(pkt.getAddress(),receivedmessage.getIp().getFirst().getPort());
				
				for(FileInfo  fichero: receivedmessage.getFiles()) {
					if(Maparchivos.containsKey(fichero)) {
						direccionesDeficheros = Maparchivos.get(fichero);
					}else {
						direccionesDeficheros= new LinkedList<>(); //sino vacia
					}
					direccionesDeficheros.add(direccion);
					Maparchivos.putIfAbsent(fichero, direccionesDeficheros); //sino esta la añade
				}
		       msgToSend = new DirMessage(DirMessageOps.OPERATION_SEND_SERVE); 
		       
			break;
			}
			case DirMessageOps.OPERATION_DOWNLOAD: {
				List<InetSocketAddress> direcciones = new ArrayList<>();
				//RECORRER TODOS LOS FICHEROS QUE TENGAN ESA SUBCADENA
				String subcadena = receivedmessage.getFiles().getFirst().fileName;
				for(FileInfo  fichero: Maparchivos.keySet()) {
					if(fichero.fileName.contains(subcadena)) {
						//si contiene la subcadena ese archivo, obtenemos todas las direcciones asociadas a ese archivo
						System.out.println("Archivo encontrado: " + fichero.fileName);
						List<InetSocketAddress> direccionesFicheroUnico = Maparchivos.get(fichero);
						direcciones.addAll(direccionesFicheroUnico);
					}
				}
				
				msgToSend = new DirMessage(DirMessageOps.OPERATION_SEND_DOWNLOAD); 
				msgToSend.setServers(direcciones.toArray(new InetSocketAddress[0])); // Asignar las direcciones al mensaje
				break;
			}
		default:
			System.err.println("Unexpected message operation: \"" + operation + "\"");
			System.exit(-1);
		}
		
		String responseString = msgToSend.toString();
		byte[] dataToClient = responseString.getBytes();
		InetSocketAddress clientAddr = (InetSocketAddress) pkt.getSocketAddress();
		DatagramPacket pktToClient = new DatagramPacket(dataToClient, dataToClient.length, clientAddr);
		socket.send(pktToClient);		
	}
}
