package es.um.redes.nanoFiles.udp.message;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import es.um.redes.nanoFiles.util.FileInfo;

/**
 * Clase que modela los mensajes del protocolo de comunicación entre pares para
 * implementar el explorador de ficheros remoto (servidor de ficheros). Estos
 * mensajes son intercambiados entre las clases DirectoryServer y
 * DirectoryConnector, y se codifican como texto en formato "campo:valor".
 * 
 * @author rtitos
 *
 */
public class DirMessage {
	public static final int PACKET_MAX_SIZE = 65507; // 65535 - 8 (UDP header) - 20 (IP header)

	private static final char DELIMITER = ':'; // Define el delimitador
	private static final char END_LINE = '\n'; // Define el carácter de fin de línea

	/**
	 * Nombre del campo que define el tipo de mensaje (primera línea)
	 */
	private static final String FIELDNAME_OPERATION = "operation";
	/*
	 * (Boletín MensajesASCII) Definir de manera simbólica los nombres de
	 * todos los campos que pueden aparecer en los mensajes de este protocolo
	 * (formato campo:valor)
	 */
	private static final String FIELDNAME_PROTOCOLID = "protocolid";
	private static final String FIELDNAME_FILENAME = "filename";
	private static final String FIELDNAME_SIZE = "size";
	private static final String FIELDNAME_HASH = "hash";
	private static final String FIELDNAME_SERVER = "server";
	private static final String FIELDNAME_PORT = "port"; // para la mejora del puerto variable

	/**
	 * Tipo del mensaje, de entre los tipos definidos en PeerMessageOps.
	 */
	private String operation = DirMessageOps.OPERATION_INVALID;
	/**
	 * Identificador de protocolo usado, para comprobar compatibilidad del
	 * directorio.
	 */
	private String protocolId;
	/*
	 * TODO: (Boletín MensajesASCII) Crear un atributo correspondiente a cada uno de
	 * los campos de los diferentes mensajes de este protocolo.
	 */
	private List<FileInfo> files = new ArrayList<>();
	private List<InetSocketAddress> servers = new ArrayList<>();
	private String fileNameSubstring;

	public void setFilenameSubstring(String filenameSubstring) {
		this.fileNameSubstring = filenameSubstring;
	}

	public String getFilenameSubstring() {
		return fileNameSubstring;
	}

	public DirMessage(String op) {
		operation = op;
		this.files = new ArrayList<>();
		this.fileNameSubstring = null;
	}

	/*
	 * (Boletín MensajesASCII) Crear diferentes constructores adecuados para
	 * construir mensajes de diferentes tipos con sus correspondientes argumentos
	 * (campos del mensaje)
	 */

	// Obtener la lista de archivos todos
	public List<FileInfo> getFiles() {
		return files;
	}

	public void setFiles(FileInfo... listaficheros) {
		Collections.addAll(files, listaficheros);
	}

	public void setServers(InetSocketAddress... listaservidores) {
		Collections.addAll(servers, listaservidores);
	}

	public String getOperation() {
		return operation;
	}

	// OPERACION DOWNLOAD

	public List<InetSocketAddress> getIp() {
		return Collections.unmodifiableList(servers);
	}

	public void addIp(InetSocketAddress ip) {
		servers.add(ip); // añadir ip a la lista
	}

	
	public void setProtocolID(String protocolIdent) {
		if (!operation.equals(DirMessageOps.OPERATION_PING)) {
			throw new RuntimeException(
					"DirMessage: setProtocolId called for message of unexpected type (" + operation + ")");
		}
		protocolId = protocolIdent;
	}

	public String getProtocolId() {
		return protocolId;
	}

	/**
	 * Método que convierte un mensaje codificado como una cadena de caracteres, a
	 * un objeto de la clase PeerMessage, en el cual los atributos correspondientes
	 * han sido establecidos con el valor de los campos del mensaje.
	 * 
	 * @param message El mensaje recibido por el socket, como cadena de caracteres
	 * @return Un objeto PeerMessage que modela el mensaje recibido (tipo, valores,
	 *         etc.)
	 */
	public static DirMessage fromString(String message) {
		String[] lines = message.split(END_LINE + "");
		DirMessage m = null;
		FileInfo file = null;
		InetSocketAddress direccion = null;
		List<FileInfo> fileList = new ArrayList<>();
		List<InetSocketAddress> direcciones = new LinkedList<>();

		for (String line : lines) {
			int idx = line.indexOf(DELIMITER); // Posición del delimitador
			String fieldName = line.substring(0, idx).toLowerCase(); // minúsculas
			String value = line.substring(idx + 1).trim();

			switch (fieldName) {
			case FIELDNAME_OPERATION: {
				assert (m == null);
				m = new DirMessage(value);
				break;
			}
			case FIELDNAME_PROTOCOLID: {
				if (m != null) {
					m.protocolId = value;
				}
				break;
			}
			case FIELDNAME_FILENAME: {
				file = new FileInfo();
				file.fileName = value;
				if (m.getOperation().equals(DirMessageOps.OPERATION_DOWNLOAD)) {
					m.setFiles(file);
				}

				break;
			}
			case FIELDNAME_HASH: {
				if (m != null) {
					file.fileHash = value;

					fileList.add(file); // como la linea es nombre tamaño y hash, hay que guardarlo para que no lea el
										// siguiente y de error
				}
				break;
			}
			case FIELDNAME_SIZE: {
				if (file != null) {
					try {
						file.fileSize = Long.parseLong(value);
					} catch (NumberFormatException e) {
						System.err.println("Error parsing file size: " + value);
					}
				}
				break;
			}
			case FIELDNAME_PORT: {
				try {
					int port = Integer.parseInt(value);
					direccion = new InetSocketAddress(port);
					if (m.getOperation().equals(DirMessageOps.OPERATION_SERVE)) {
						direcciones.add(direccion);
						m.setServers(direcciones.toArray(new InetSocketAddress[0]));
					}
				} catch (NumberFormatException e) {
					System.err.println("Error parsing port: " + value);
				}
				break;
			}
			case FIELDNAME_SERVER: {
				try {
					if (direccion != null) { // como pone /IP tenemos que quitar la barra para que coja solo la ip del
												// servidor
						direccion = new InetSocketAddress(InetAddress.getByName(value.substring(1)),
								direccion.getPort());
						direcciones.add(direccion);
					}
				} catch (UnknownHostException e) {
					System.err.println("Error parsing server address: " + value);
				}
				break;
			}
			default:
				System.err.println("PANIC: DirMessage.fromString - message with unknown field name " + fieldName);
				System.err.println("Message was:\n" + message);
				System.exit(-1);
			}
		}
		if (!fileList.isEmpty()) {
			m.setFiles(fileList.toArray(new FileInfo[0]));
		}
		if (m.getOperation().equals(DirMessageOps.OPERATION_SEND_DOWNLOAD)) {
			m.setServers(direcciones.toArray(new InetSocketAddress[0]));
		}

		return m;
	}

	/**
	 * Método que devuelve una cadena de caracteres con la codificación del mensaje
	 * según el formato campo:valor, a partir del tipo y los valores almacenados en
	 * los atributos.
	 * 
	 * @return La cadena de caracteres con el mensaje a enviar por el socket.
	 */
	public String toString() {

		StringBuffer sb = new StringBuffer();
		sb.append(FIELDNAME_OPERATION + DELIMITER + operation + END_LINE); // Construimos el campo

		if (operation.equals(DirMessageOps.OPERATION_PING)) {
			if (protocolId != null) {
				sb.append(FIELDNAME_PROTOCOLID + DELIMITER + getProtocolId() + END_LINE);
			} else {
				System.err.println("No hay un protocolID establecido, es null.");
			}
		}

		if (operation.equals(DirMessageOps.OPERATION_FILELIST)) {
		}
		if (operation.equals(DirMessageOps.OPERATION_SEND_FILELIST)) {

			for (FileInfo ficheros : files) {
				sb.append(FIELDNAME_FILENAME + DELIMITER + ficheros.fileName + END_LINE);
				sb.append(FIELDNAME_SIZE + DELIMITER + ficheros.fileSize + END_LINE);
				sb.append(FIELDNAME_HASH + DELIMITER + ficheros.fileHash + END_LINE);
			}
		}
		if (operation.equals(DirMessageOps.OPERATION_SERVE)) {
			sb.append(FIELDNAME_PORT + DELIMITER + servers.getFirst().getPort() + END_LINE);

			for (FileInfo ficheros : files) {
				sb.append(FIELDNAME_FILENAME + DELIMITER + ficheros.fileName + END_LINE);
				sb.append(FIELDNAME_SIZE + DELIMITER + ficheros.fileSize + END_LINE);
				sb.append(FIELDNAME_HASH + DELIMITER + ficheros.fileHash + END_LINE);
			}
		}
		if (operation.equals(DirMessageOps.OPERATION_SEND_SERVE)) {
		}
		if (operation.equals(DirMessageOps.OPERATION_DOWNLOAD)) {
			if (!files.isEmpty()) {
				sb.append(FIELDNAME_FILENAME + DELIMITER + getFiles().getFirst().fileName + END_LINE);
			} else {
				System.err.println("La lista de archivos está vacía.");
			}
		}
		if (operation.equals(DirMessageOps.OPERATION_SEND_DOWNLOAD)) {
			for (InetSocketAddress ficheros : servers) {
				sb.append(FIELDNAME_PORT + DELIMITER + ficheros.getPort() + END_LINE);
				sb.append(FIELDNAME_SERVER + DELIMITER + ficheros.getAddress() + END_LINE);
			}
		}

		sb.append(END_LINE); // Marcamos el final del mensaje
		return sb.toString();
	}

}
