package es.um.redes.nanoFiles.tcp.server;

import java.net.Socket;

public class NFServerThread extends Thread {

	private Socket socketPrivadoParaCliente;

	public NFServerThread(Socket socket) {
		this.socketPrivadoParaCliente = socket;
	}

	public void run() {
		NFServer.serveFilesToClient(socketPrivadoParaCliente);
	}
}

