package es.um.redes.nanoFiles.tcp.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import es.um.redes.nanoFiles.tcp.message.PeerMessage;
import es.um.redes.nanoFiles.tcp.message.PeerMessageOps;
import es.um.redes.nanoFiles.util.FileDigest;

//Esta clase proporciona la funcionalidad necesaria para intercambiar mensajes entre el cliente y el servidor
public class NFConnector {
	private Socket socket;
	private InetSocketAddress serverAddr;
	private DataInputStream dis;
	private DataOutputStream dos;

	//Constructor
	public NFConnector(InetSocketAddress fserverAddr) throws UnknownHostException, IOException {
		serverAddr = fserverAddr;
		socket = new Socket(serverAddr.getAddress(), serverAddr.getPort());
		dis = new DataInputStream(socket.getInputStream());
		dos = new DataOutputStream(socket.getOutputStream());
	}

	public void test() {
		try {
			PeerMessage msgOut = new PeerMessage(PeerMessageOps.OPCODE_FILE_NOT_FOUND);
			msgOut.writeMessageToOutputStream(dos); // Enviar el mensaje al servidor
			System.out.println("Mensaje enviado al servidor: " + msgOut.getOpcode());
		} catch (IOException e) {
			System.err.println("Error recibiendo el mensaje PeerMessage.");
		}
	}

	public PeerMessage sendAndReceivePeerMessage(PeerMessage msgOut) {
		PeerMessage msgIn = null;
		try {
			msgOut.writeMessageToOutputStream(dos);
			msgIn = PeerMessage.readMessageFromInputStream(dis);
		} catch (IOException e) {
			System.err.println("Error: NFConnector:sendAndReceivePeerMessage(1)");
		}
		return msgIn;
	}

	public InetSocketAddress getServerAddr() {
		return serverAddr;
	}

}
