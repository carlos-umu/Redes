package es.um.redes.nanoFiles.tcp.message;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

public class PeerMessageTest {

	public static void main(String[] args) throws IOException {
		String nombreArchivo = "peermsg.bin";
		DataOutputStream fos = new DataOutputStream(new FileOutputStream(nombreArchivo));

		// PeerMessage msgOut = new PeerMessage(PeerMessageOps.OPCODE_FILE_NOT_FOUND);
		// PeerMessage msgOut = new PeerMessage(PeerMessageOps.OPCODE_CHUNK);
		// PeerMessage msgOut = new PeerMessage(PeerMessageOps.OPCODE_ALL_DOWNLOAD);
		// String nombre="salchichon.png";
		// PeerMessage msgOut = new
		// PeerMessage(PeerMessageOps.OPCODE_DOWNLOAD,(short)nombre.getBytes().length,nombre.getBytes());
		// PeerMessage msgOut = new PeerMessage(PeerMessageOps.OPCODE_GET_CHUNK,
		// 10,2048);//10es el desplaz q es un long y el tamchunk es 2048 q es un int
		String hash = "A1B2C3D4E5";
		PeerMessage msgOut = new PeerMessage(PeerMessageOps.OPCODE_HASH, (short) hash.getBytes().length,
				hash.getBytes());
		msgOut.writeMessageToOutputStream(fos);// escribe en archivo

		DataInputStream fis = new DataInputStream(new FileInputStream(nombreArchivo));
		PeerMessage msgIn = PeerMessage.readMessageFromInputStream((DataInputStream) fis);
		/*
		 * TODO: Comprobar que coinciden los valores de los atributos relevantes al tipo
		 * de mensaje en ambos mensajes (msgOut y msgIn), empezando por el opcode.
		 */
		if (msgOut.getOpcode() != msgIn.getOpcode()) {
			System.err.println("Opcode does not match!");
		}
		if (msgOut.getlongitudBytesValor() != msgIn.getlongitudBytesValor()) {
			System.err.println("No coincide longitud");
		}
		if (!Arrays.equals(msgOut.getValor(), msgIn.getValor())) {
			System.err.println("No coincide valor");
		}
		if (msgOut.getParametro1() != msgIn.getParametro1()) {
			System.err.println("No coincide parametro 1");
		}
		if (msgOut.getParametro2() != msgIn.getParametro2()) {
			System.err.println("No coincide parametro 2");
		}

	}

}
