package es.um.redes.nanoFiles.tcp.message;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

import es.um.redes.nanoFiles.util.FileInfo;

public class PeerMessage {

	private byte opcode; // todos los formatos
	private long parametro1; // formato operacion
	private int parametro2; // formato operacion
	private short longitudBytesValor; // formato TLV
	private byte[] valor; // formato TLV

	public PeerMessage() {
		opcode = PeerMessageOps.OPCODE_INVALID_CODE;
	}

	// Formato Control
	public PeerMessage(byte op) {
		opcode = op;
	}

	// Formato Operacion
	public PeerMessage(byte op, long desplazamiento, int tam_chunk) {
		opcode = op;
		parametro1 = desplazamiento;
		parametro2 = tam_chunk;

	}

	// Formato TLV
	public PeerMessage(byte op, short longitud, byte[] valor) {
		if (valor.length == longitud) {		 // Convertir array de bytes a numero
			opcode = op;
			longitudBytesValor = longitud;	 
			this.valor = valor;
		} else {
			System.err.println("Error creando Peermesage.(1)");
		}
	}

	// Getters
	public byte getOpcode() {
		return opcode;
	}

	public long getParametro1() {
		return parametro1;
	}

	public int getParametro2() {
		return parametro2;
	}

	public short getlongitudBytesValor() {
		return longitudBytesValor;
	}

	public byte[] getValor() {
		return valor;
	}

	// Setters
	public void setParametro1(long parametro1) {
		this.parametro1 = parametro1;
	}

	public void setParametro2(int parametro2) {
		this.parametro2 = parametro2;
	}

	public void setlongitudBytesValor(short parametro1) {
		this.longitudBytesValor = parametro1;
	}

	public void setValor(byte[] parametro2) {
		this.valor = parametro2;
	}

	/**
	 * Método de clase para parsear los campos de un mensaje y construir el objeto
	 * DirMessage que contiene los datos del mensaje recibido
	 * 
	 * @param data El array de bytes recibido
	 * @return Un objeto de esta clase cuyos atributos contienen los datos del
	 *         mensaje recibido.
	 * 
	 */

	public static PeerMessage readMessageFromInputStream(DataInputStream dis) throws IOException {

		PeerMessage message = null;
		byte opcode = dis.readByte();

		switch (opcode) {
		case (PeerMessageOps.OPCODE_FILE_NOT_FOUND): {
			message = new PeerMessage(opcode);
			break;
		}
		case (PeerMessageOps.OPCODE_MORE_THAN_ONE_FILE): {
			message = new PeerMessage(opcode);
			break;
		}
		case (PeerMessageOps.OPCODE_CHUNK): {
			short longitudBytesValor = dis.readShort();
			byte[] valor = new byte[longitudBytesValor];
			dis.readFully(valor);
			message = new PeerMessage(opcode, longitudBytesValor, valor);
			break;
		}
		case (PeerMessageOps.OPCODE_DOWNLOAD):
		case (PeerMessageOps.OPCODE_HASH): {
			short longitudBytesValor = dis.readShort();
			byte[] valor = new byte[longitudBytesValor];
			dis.readFully(valor);
			message = new PeerMessage(opcode, longitudBytesValor, valor);
			break;
		}
		case (PeerMessageOps.OPCODE_RESPUESTA_TAM): {
			short longitudBytesValor = dis.readShort();
			byte[] valor = new byte[longitudBytesValor];
			dis.readFully(valor);
			message = new PeerMessage(opcode, longitudBytesValor, valor);
			break;
		}
		case (PeerMessageOps.OPCODE_SOLICITUD_TAM): {
			short longitudBytesValor = dis.readShort();
			byte[] valor = new byte[longitudBytesValor];
			dis.readFully(valor);
			message = new PeerMessage(opcode, longitudBytesValor, valor);
			break;
		}
		case (PeerMessageOps.OPCODE_GET_CHUNK): {// opcode=4
			long desplaz = dis.readLong();
			int tam_chunk = dis.readInt();
			message = new PeerMessage(opcode, desplaz, tam_chunk);
			break;
		}
		default:
			System.err.println("PeerMessage.readMessageFromInputStream doesn't know how to parse this message opcode: "
					+ PeerMessageOps.opcodeToOperation(opcode));
			System.exit(-1);
		}
		return message;
	}

	public void writeMessageToOutputStream(DataOutputStream dos) throws IOException {
		dos.writeByte(opcode);
		switch (opcode) {
		case (PeerMessageOps.OPCODE_DOWNLOAD): {
			dos.writeShort(longitudBytesValor);
			dos.write(valor);
			break;
		}
		case (PeerMessageOps.OPCODE_FILE_NOT_FOUND): {
			break;
		}
		case (PeerMessageOps.OPCODE_MORE_THAN_ONE_FILE): {
			break;
		}
		case (PeerMessageOps.OPCODE_HASH): {
			dos.writeShort(longitudBytesValor);
			dos.write(valor);
			break;
		}
		case (PeerMessageOps.OPCODE_RESPUESTA_TAM): {
			dos.writeShort(longitudBytesValor);
			dos.write(valor);
			break;
		}
		case (PeerMessageOps.OPCODE_SOLICITUD_TAM): {
			dos.writeShort(longitudBytesValor);
			dos.write(valor);
			break;
		}
		case (PeerMessageOps.OPCODE_GET_CHUNK): {
			dos.writeLong(parametro1);
			dos.writeInt(parametro2);
			break;
		}
		case (PeerMessageOps.OPCODE_CHUNK): {
			dos.writeShort(longitudBytesValor);
			dos.write(valor);
			break;
		}
		default:
			System.err.println("PeerMessage.writeMessageToOutputStream found unexpected message opcode " + opcode + "("
					+ PeerMessageOps.opcodeToOperation(opcode) + ")");
		}
	}

}
