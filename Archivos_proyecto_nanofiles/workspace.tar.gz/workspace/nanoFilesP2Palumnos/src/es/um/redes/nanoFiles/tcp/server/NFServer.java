package es.um.redes.nanoFiles.tcp.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

import es.um.redes.nanoFiles.application.NanoFiles;
import es.um.redes.nanoFiles.tcp.message.PeerMessage;
import es.um.redes.nanoFiles.tcp.message.PeerMessageOps;
import es.um.redes.nanoFiles.util.FileInfo;

public class NFServer implements Runnable {

	public static final int PORT = 10000;
	private ServerSocket serverSocket = null;
	private boolean stopServer = false;
	private static FileInfo archivo= null;
	
	public int getServerPort() {
		return this.serverSocket.getLocalPort();
	}

	public ServerSocket getServer() {
		return serverSocket;
	}
	public void stopServer() {
		try {
			this.serverSocket.close();
		} catch (IOException e) {
			System.err.println("Error cerrando servidor.");
		}
	}

	public void start() {
		new Thread(this).start();
	}

	public NFServer() throws IOException {
		try {
			// Crear el ServerSocket y vincularlo al puerto especificado
			InetSocketAddress serverSocketAddress = new InetSocketAddress(PORT);			
			serverSocket = new ServerSocket();
			serverSocket.bind(serverSocketAddress);
			System.out.println("Servidor escuchando en " + PORT);
		} catch (IOException e) {
			System.err.println("Error en el puerto del server socket.");
			System.err.println("Address already in use: bind");
		}

		
	}

	/**
	 * Método para ejecutar el servidor de ficheros en primer plano. Sólo es capaz
	 * de atender una conexión de un cliente. Una vez se lanza, ya no es posible
	 * interactuar con la aplicación.
	 * 
	 */
	public void test() { 
		if (serverSocket == null || !serverSocket.isBound()) {
			System.err.println(
					"[fileServerTestMode] Failed to run file server, server socket is null or not bound to any port");
			return;
		} else {
			System.out
					.println("[fileServerTestMode] NFServer running on " + serverSocket.getLocalSocketAddress() + ".");
		}

		while (true) {
			try {
				Socket socket = serverSocket.accept();
				System.out.println("Se ha establecido una conexion");

				DataInputStream dis = new DataInputStream(socket.getInputStream());
				DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
				
				PeerMessage msgIn = PeerMessage.readMessageFromInputStream(dis);
				System.out.println("Mensaje recibido del cliente: " + msgIn.getOpcode());
				if (msgIn.getOpcode() == PeerMessageOps.OPCODE_FILE_NOT_FOUND) {
					System.out.println("Llega bien el mensaje.");
				} else {
					System.out.println("No llega bien el mensaje." + msgIn.getOpcode());
				}
				socket.close(); 
			} catch (IOException e) {
				System.err.println("Error en la espera de las solicitudes en el servidor.");
			}
		}
	}

	/**
	 * Método que ejecuta el hilo principal del servidor en segundo plano, esperando
	 * conexiones de clientes.
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		if (serverSocket == null || !serverSocket.isBound()) {
			System.err.println("El servidor no esta bien inicializado");
			return;
		}

		while (true) {
			try {

				Socket socket = serverSocket.accept();// Espera conexiones de clientes
				System.out.println("New client connected: " + socket.getInetAddress().toString() + ":" + socket.getPort());
				NFServerThread hilo = new NFServerThread(socket); // con esta conexion hay que crear un hilo nuevo
				hilo.start();
			} catch (IOException ex) {
				System.out.println("Server exception: " + ex.getMessage());
				System.err.println("Error: bucle while(true) NFServer.run.");
			}
		}
	}

	/**
	 * Método de clase que implementa el extremo del servidor del protocolo de
	 * transferencia de ficheros entre pares.
	 * 
	 * @param socket El socket para la comunicación con un cliente que desea
	 *               descargar ficheros.
	 */
	public static void serveFilesToClient(Socket socket) {
		try {
			DataInputStream dis = new DataInputStream(socket.getInputStream());
			DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

			while (true) {// mientras el cliente esta conectado

				PeerMessage mensaje = PeerMessage.readMessageFromInputStream(dis);
				PeerMessage mensajeout = null;
				
				switch (mensaje.getOpcode()) {
				case PeerMessageOps.OPCODE_DOWNLOAD:
					//Buscar entre archivos, con una subcadena
					//Te devuelve un array con todos los archivos que contengan esa subcadena
					FileInfo[] archivos = FileInfo.lookupFilenameSubstring(NanoFiles.db.getFiles(), new String(mensaje.getValor()));
					if(archivos.length==1) {
						 archivo=archivos[0]; //coger el primero como referencia para comparar
						mensajeout= new PeerMessage(PeerMessageOps.OPCODE_HASH, (short)archivo.fileHash.getBytes().length,archivo.fileHash.getBytes());
					}
					else if(archivos.length==0) {
						//Ningun resultado en la busqueda
						mensajeout= new PeerMessage(PeerMessageOps.OPCODE_FILE_NOT_FOUND);
					}else { 
						//Mas de un archivo encontrado
						mensajeout= new PeerMessage(PeerMessageOps.OPCODE_MORE_THAN_ONE_FILE);		
					}
					break;
					
					
				case PeerMessageOps.OPCODE_GET_CHUNK:
					//Chunk a partir de un valor aleatorio en adelante
					RandomAccessFile archivoleido= new RandomAccessFile(NanoFiles.db.lookupFilePath(archivo.fileHash),"r");
					archivoleido.seek(mensaje.getParametro1());
					byte[] chunk = new byte[mensaje.getParametro2()];
					archivoleido.readFully(chunk);
					archivoleido.close();
					//Mandamos el send_chunk
					mensajeout= new PeerMessage(PeerMessageOps.OPCODE_CHUNK,(short)chunk.length,chunk);
					break;
					
					
				case PeerMessageOps.OPCODE_SOLICITUD_TAM:
					//Si nos piden el tamaño pasamos el archivo a bytes y lo pasamos por el mensaje Respuesta_tam
					byte[] tam= Long.toString(archivo.fileSize).getBytes();
					mensajeout=new PeerMessage(PeerMessageOps.OPCODE_RESPUESTA_TAM,(short)tam.length,tam);
					break;
					
					
				default:
					break;
				}
				mensajeout.writeMessageToOutputStream(dos);
			}
		} catch (IOException e) {
			System.err.println("Fallo en NFServer.serveFileToClient.");
		}
	}
}
