package es.um.redes.nanoFiles.udp.message;

public class DirMessageOps {

	public static final String OPERATION_INVALID = "invalid_operation";

	public static final String OPERATION_PING = "ping";
	public static final String OPERATION_WELCOME = "welcome";
	public static final String OPERATION_DENIED = "denied";

	public static final String OPERATION_FILELIST = "filelist";
	public static final String OPERATION_SEND_FILELIST = "sendfilelist";

	public static final String OPERATION_SUCCESS = "success";

	public static final String OPERATION_SERVE = "serve";
	public static final String OPERATION_SEND_SERVE = "sendserve";

	public static final String OPERATION_DOWNLOAD = "download";
	public static final String OPERATION_SEND_DOWNLOAD = "send_download";

}

