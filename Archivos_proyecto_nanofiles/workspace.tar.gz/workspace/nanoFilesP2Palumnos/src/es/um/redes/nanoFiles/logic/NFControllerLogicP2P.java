package es.um.redes.nanoFiles.logic;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import es.um.redes.nanoFiles.application.NanoFiles;
import es.um.redes.nanoFiles.tcp.client.NFConnector;
import es.um.redes.nanoFiles.tcp.message.PeerMessage;
import es.um.redes.nanoFiles.tcp.message.PeerMessageOps;
import es.um.redes.nanoFiles.tcp.server.NFServer;
import es.um.redes.nanoFiles.util.FileDigest;
import es.um.redes.nanoFiles.util.FileInfo;

public class NFControllerLogicP2P {
	
	private NFServer fileServer;
	private int port;
    NFConnector nfConector; 						//cliente conectar con otros peers
	private NFControllerLogicDir controllerDir;		//controlador para acceder al directorio

	protected NFControllerLogicP2P() {}

	/**
	 * Método para ejecutar un servidor de ficheros en segundo plano. Debe arrancar
	 * el servidor en un nuevo hilo creado a tal efecto.
	 * 
	 * @return Verdadero si se ha arrancado en un nuevo hilo con el servidor de
	 *         ficheros, y está a la escucha en un puerto, falso en caso contrario.
	 * 
	 */
	protected boolean startFileServer() {
		boolean serverRunning = false;
		
		if (fileServer != null) {
			System.err.println("File server is already running.");
		} else {

			try {
				this.fileServer= new NFServer();
				fileServer.start();
				if(fileServer.getServerPort()>0) { 
					System.out.println("NFServer server en:" +fileServer.getServer());
					System.out.println("Servidor iniciado correctamente, puerto: "+ fileServer.getServerPort());
					serverRunning=true;
				}
			} catch (IOException e) {
				System.err.println("Hubo un problema con la creacion del NFServer");
			}

		}
		return serverRunning;
	}

	/*
	 * (Boletín SocketsTCP) Inicialmente, se creará un NFServer y se ejecutará su
	 * método "test" (servidor minimalista en primer plano, que sólo puede atender a
	 * un cliente conectado). Posteriormente, se desactivará "testModeTCP" para
	 * implementar un servidor en segundo plano, que se ejecute en un hilo
	 * secundario para permitir que este hilo (principal) siga procesando comandos
	 * introducidos mediante el shell.
	 */
	/*
	 * Comprobar que no existe ya un objeto NFServer previamente creado, en cuyo
	 * caso el servidor ya está en marcha.
	 */
	protected void testTCPServer() {
		assert (NanoFiles.testModeTCP);
		
		assert (fileServer == null);
		try {
			fileServer = new NFServer();
			fileServer.test();
		} catch (IOException e1) {
			e1.printStackTrace();
			System.err.println("Cannot start the file server");
			fileServer = null;
		}
	}

	public void testTCPClient() {

		assert (NanoFiles.testModeTCP);
		/*
		 * (Boletín SocketsTCP) Inicialmente, se creará un NFConnector (cliente TCP)
		 * para conectarse a un servidor que esté escuchando en la misma máquina y un
		 * puerto fijo. Después, se ejecutará el método "test" para comprobar la
		 * comunicación mediante el socket TCP. Posteriormente, se desactivará
		 * "testModeTCP" para implementar la descarga de un fichero desde múltiples
		 * servidores.
		 */

		try {
			NFConnector nfConnector = new NFConnector(new InetSocketAddress(NFServer.PORT));
			nfConnector.test();
		} catch (IOException e) {
			System.err.println("Error en NFControllerLogicP2P.testTCPClient.");
		}
	}

	/**
	 * Método para descargar un fichero del peer servidor de ficheros
	 * 
	 * @param serverAddressList       La lista de direcciones de los servidores a
	 *                                los que se conectará
	 * @param targetFileNameSubstring Subcadena del nombre del fichero a descargar
	 * @param localFileName           Nombre con el que se guardará el fichero
	 *                                descargado
	 */
	protected boolean downloadFileFromServers(InetSocketAddress[] serverAddressList, String targetFileNameSubstring,String localFileName) {
		boolean downloaded = false; 

		//Si no te pasan array no puedes descargar
		if (serverAddressList.length == 0) { 
			System.err.println("No se puede descargar, no hay ningun servidor con ese fichero.");
			return false;
		}
		//Creamos la lista de NFConnector y los recrorremos
		LinkedList<NFConnector> connectores= new LinkedList<>();		 
		for (int i=0; i<serverAddressList.length;i++) {					 
			try {
				connectores.add(new NFConnector(serverAddressList[i]));	
			} catch (UnknownHostException e) {
				System.err.println("Error insertando en la lista, no se puede conectar con un servidor.");
			} catch (IOException e) {
				System.err.println("Error insertando en la lista.");
			}
        }
		//Error: Si el nombre que le quieres poner ya existe entre tus ficheros
		for (FileInfo file  : NanoFiles.db.getFiles()) { 
			if(file.fileName.equals(localFileName)) {
				System.err.println("Ya existe un fichero con ese nombre:" + file.fileName);
				return false;
			}
		}
		//Crear un conjunto que almacene todos los hashes de los mensajes recibidos
		 Set<String> hashes= new HashSet<>();		
		 PeerMessage peticion= new PeerMessage(PeerMessageOps.OPCODE_DOWNLOAD,(short)targetFileNameSubstring.getBytes().length,targetFileNameSubstring.getBytes());
		//Pedir el hash al servidor para que te los devuelva
		 PeerMessage recibido= null;
		 
		 //Pedimos el archivo a cada servidor de la lista nfconectors , para que nos devuelva su hash
		 for (NFConnector c  : connectores) { 
				recibido= c.sendAndReceivePeerMessage(peticion);
				if(recibido.getOpcode() != PeerMessageOps.OPCODE_HASH) { 
					//Si no encuentra manda PeerMessageOps.FILE_NOT_FOUND 
					//Si encuentra varios manda PeerMessageOps.MORE_THAN_ONE_FILE
					System.err.println("Error 0 o mas de un archivo con ese nombre");
					return false;
				}
				//Si solo hay uno se añade, esto solo se ejecuta si el opcode es hash
				hashes.add(new String(recibido.getValor()));			
			}
		 
		 //Comprobar que todos los hashes sean iguales
		 if(hashes.size()!=1) {
			 System.err.println("No todos los archivos son iguales");
			 return false;
		 }
		 
		 //Solicitar el tamaño del fichero
		 peticion= new PeerMessage(PeerMessageOps.OPCODE_SOLICITUD_TAM,(short)targetFileNameSubstring.getBytes().length,targetFileNameSubstring.getBytes());
		
		 recibido= connectores.getFirst().sendAndReceivePeerMessage(peticion);
		 
		 //Convertir el valor recibido en un long
		 long tam= Long.parseLong(new String(recibido.getValor()));
		 
		 //Dividir el fichero en trozos, tam fichero/servidores, (consejo del profesor tamaño entre numero de servidores)
		 //Forma mas recomendable(Según el profesor)
		 int tam_trozos = (int) tam/connectores.size();
		 int trozos_descargados=0; //contador de los que llevas descargados
		 
		 //El outputStream es como una caja a la que le metes los bytes que quieras, y al final creas el fichero con esos bytes
		 ByteArrayOutputStream outputStream = new ByteArrayOutputStream(); 
		 
		//Vas pidiendo todos los chunk que necesites de cada NFConnector
		 for (NFConnector c  : connectores) { 
			 	peticion=new PeerMessage(PeerMessageOps.OPCODE_GET_CHUNK,trozos_descargados* tam_trozos ,tam_trozos);
				recibido= c.sendAndReceivePeerMessage(peticion);
				try {
					outputStream.write(recibido.getValor());
				} catch (IOException e) {
					System.err.println("Error en NFControllerP2P.dowloadFileFromServers(1).");
				}
				trozos_descargados++;
			}
		 
		//Es posible que la division no sea exacta y te falte algun byte o trozo, aqui solicitas ese trozo
		 if(tam_trozos * trozos_descargados < tam) {
			 peticion=new PeerMessage(PeerMessageOps.OPCODE_GET_CHUNK,trozos_descargados* tam_trozos ,tam_trozos);
				recibido= connectores.getFirst().sendAndReceivePeerMessage(peticion);
				try {
					outputStream.write(recibido.getValor());
				} catch (IOException e) {
					System.err.println("Error en NFControllerP2P.dowloadFileFromServers(2).");
				}

		 }
		 
		 //Volcamos el contenido del outputStream en un array de bytes
		 byte[] sacararchivo = outputStream.toByteArray();
		 
		 //Escribimos en el archivo
		 try {
			 File a = new File(NanoFiles.DEFAULT_SHARED_DIRNAME,localFileName);
			 if(!a.exists()) {
				 a.createNewFile();
				 FileOutputStream fos = new FileOutputStream(a);
				 fos.write(sacararchivo);
				 fos.close();
			 }
		 }catch(FileNotFoundException e) {
			 System.err.println("Error en NFControllerP2P.dowloadFileFromServers(3).");
		 }catch(IOException e) {
			 System.err.println("Error en NFControllerP2P.dowloadFileFromServers(4).");
		 }
		 
		 //Almacenas el hash del fichero que acabas de descargar
		 String hashArchivoDescargado= FileDigest.computeFileChecksumString(NanoFiles.DEFAULT_SHARED_DIRNAME + "/" + localFileName);
		 
		 //Si la lista de hashes contiene ese hash significa que se ha descargado con exito
		 if(hashes.contains(hashArchivoDescargado)) { 
			 System.out.println("Se ha completado la descarga.");
			 downloaded=true;
		 }else {
			 System.err.println("No se ha completado la descarga.");
			 downloaded=false;
		 }
	    return downloaded;
	}

	/**
	 * Método para obtener el puerto de escucha de nuestro servidor de ficheros
	 * 
	 * @return El puerto en el que escucha el servidor, o 0 en caso de error.
	 */
	protected int getServerPort() {
		return fileServer.getServerPort();
	}

	/**
	 * Método para detener nuestro servidor de ficheros en segundo plano
	 * 
	 */
	protected void stopFileServer() {
		//serverRunning = false;
		//parar el file server
	}

	protected boolean serving() {
		boolean result = false;
		return result;

	}

	protected boolean uploadFileToServer(FileInfo matchingFile, String uploadToServer) {
		boolean result = false;
		return result;
	}

}
